---
title: Buttons
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi nec imperdiet turpis. Curabitur aliquet pulvinar ultrices.
Etiam at posuere leo. Proin ultrices ex et dapibus feugiat [link example](#) aenean purus leo, faucibus at elit vel, aliquet scelerisque dui.
Etiam quis elit euismod, imperdiet augue sit amet, imperdiet odio. Aenean sem erat, hendrerit  eu gravida id, dignissim ut ante.
Nam consequat porttitor libero euismod congue.


<div class="row">
 <div class="col-md-6 col-sm-6 col-xs-12">

###### Basic Buttons

{: .list .list-unstyled}
- [Primary Button ](#){: .btn .btn-primary}
- [Green Button   ](#){: .btn .btn-green}
- [Blue Button    ](#){: .btn .btn-blue}
- [Orange Button  ](#){: .btn .btn-orange}
- [Red Button     ](#){: .btn .btn-red}

 </div>
 <div class="col-md-6 col-sm-6 col-xs-12">

###### CTA Buttons

{: .list .list-unstyled}
- [*&nbsp;*{: .fa .fa-download}           Download Now  ](#){: .btn .btn-primary .btn-cta}
- [*&nbsp;*{: .fa .fa-code-fork}          Fork Now      ](#){: .btn .btn-green .btn-cta}
- [*&nbsp;*{: .fa .fa-play-circle}        Find Out Now  ](#){: .btn .btn-blue .btn-cta}
- [*&nbsp;*{: .fa .fa-bug}                Report Bugs   ](#){: .btn .btn-orange .btn-cta}
- [*&nbsp;*{: .fa .fa-exclamation-circle} Submit Issues ](#){: .btn .btn-red .btn-cta}

 </div>
</div>
