---
title: Callouts
---

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.
Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.
In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.


<div class="callout-block callout-info"><div class="icon-holder" markdown="1">*&nbsp;*{: .fa .fa-info-circle}
</div><div class="content" markdown="1">
{: .callout-title}
#### Aenean imperdiet

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium `<code>`,
Nemo enim ipsam voluptatem quia voluptas [link example](#) sit aspernatur aut odit aut fugit.

</div></div>


<div class="callout-block callout-warning"><div class="icon-holder" markdown="1">*&nbsp;*{: .fa .fa-bug}
</div><div class="content" markdown="1">
{: .callout-title}
#### Morbi posuere

Nunc hendrerit odio quis dignissim efficitur. Proin ut finibus libero. Morbi posuere fringilla felis eget sagittis.
Fusce sem orci, cursus in tortor [link example](#) tellus vel diam viverra elementum.
		
</div></div>


<div class="callout-block callout-success"><div class="icon-holder" markdown="1">*&nbsp;*{: .fa .fa-thumbs-up}
</div><div class="content" markdown="1">
{: .callout-title}
#### Lorem ipsum dolor sit amet

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. [Link example](#) aenean commodo ligula eget dolor.

</div></div>


<div class="callout-block callout-danger"><div class="icon-holder" markdown="1">*&nbsp;*{: .fa .fa-exclamation-triangle}
</div><div class="content" markdown="1">
{: .callout-title}
#### Interdum et malesuada

Morbi eget interdum sapien. Donec sed turpis sed nulla lacinia accumsan vitae ut tellus.
Aenean vestibulum [Link example](#) maximus ipsum vel dignissim.
Morbi ornare elit sit amet massa feugiat, viverra dictum ipsum pellentesque.

</div></div>
