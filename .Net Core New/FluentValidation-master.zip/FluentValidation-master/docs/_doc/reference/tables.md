---
title: Tables
---

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.
Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis.


###### Basic Table

<div class="table-responsive">

{: .table}
| # | First Name | Last Name | Username
|-
| 1 | Mark       | Otto      | @mdo
| 2 | Jacob      | Thornton  | @fat
| 3 | Larry      | the Bird  | @twitter

</div>

###### Bordered Table

<div class="table-responsive">

{: .table .table-striped}
| # | First Name | Last Name | Username
|-
| 1 | Mark       | Otto      | @mdo
| 2 | Jacob      | Thornton  | @fat
| 3 | Larry      | the Bird  | @twitter

</div>


###### Striped Table

<div class="table-responsive">

{: .table .table-bordered}
| # | First Name | Last Name | Username
|-
| 1 | Mark       | Otto      | @mdo
| 2 | Jacob      | Thornton  | @fat
| 3 | Larry      | the Bird  | @twitter

</div>
