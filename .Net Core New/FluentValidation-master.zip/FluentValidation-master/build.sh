powershell -noprofile ./build.ps1 $@
