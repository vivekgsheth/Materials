using System;
using System.Reflection;

[assembly : AssemblyVersion("8.0.0.0")]
