﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC6AsyncAwait.Models;
using NewsServiceReference;
using WeatherServiceReference;

namespace MVC6AsyncAwait.Controllers
{
    public class HomeController : Controller
    {
        public async Task<IActionResult> Index()
        {
            var model = new MyModel();
            var hltask = gethlasync(model);
            var temptask = gettempasync(model);
            await Task.WhenAll(hltask, temptask);           
            return View(model);
        }
        async Task gethlasync(MyModel model)
        {
            var newsclient = new NewsServiceClient();
            model.Headline = await newsclient.GetHeadLineAsync();
        }
        async Task gettempasync(MyModel model)
        {
            var weatherclient = new WeatherServiceClient();
            model.Temperature = await weatherclient.GetTemperatureAsync();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
