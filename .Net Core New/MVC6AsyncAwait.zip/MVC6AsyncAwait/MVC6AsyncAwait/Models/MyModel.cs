﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC6AsyncAwait.Models
{
    public class MyModel
    {
        public string Headline { get; set; }
        public string Temperature { get; set; }
    }
}
