﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class WeatherService : IWeatherService
{
    public string GetTemperature()
    {
        string x = System.DateTime.Now.ToLongTimeString();
        Thread.Sleep(2000);
        return "Temperature is 30" +
            x + "GST rates increased!" +
            "Ending time is" + System.DateTime.Now.ToLongTimeString();

    }
}
