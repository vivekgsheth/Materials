﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.Xml.Linq;

namespace ConsoleClient
{
    public class Student
    {       
        public int Sid { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Class { get; set; }
        public string SchoolName { get; set; }
        public string City { get; set; }

    }
    class Program
    {
        static void Main(string[] args)
        {
            RunAsync().Wait();
        }
        static async Task RunAsync()
        {
            using(var client=new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44350/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //http GET
                HttpResponseMessage response = await client.GetAsync("api/student/1");
                if (response.IsSuccessStatusCode)
                {
                    Student obj = await response.Content.ReadAsAsync<Student>();
                    Console.WriteLine("{0}\t{1}\t{2}", obj.Name, obj.SchoolName, obj.Email);
                    Console.ReadKey();
                }
            }

        }
    }
}
