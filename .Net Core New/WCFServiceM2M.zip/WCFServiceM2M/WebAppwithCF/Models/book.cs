﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppwithCF.Models
{
    public class book
    {
        public book()
        {
            this.authorbooks = new HashSet<authorbook>();
        }
        [Key]
        public int bid { get; set; }
        public string btitle { get; set; }
       public virtual ICollection<authorbook> authorbooks { get; set; }
    }
}
