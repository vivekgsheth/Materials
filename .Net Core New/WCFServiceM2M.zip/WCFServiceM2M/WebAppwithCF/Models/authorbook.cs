﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppwithCF.Models
{
    public class authorbook
    {
        [Key]
        public int mixedId { get; set; }
        public int aid { get; set; }
        
        public int bid { get; set; }
        public Nullable<int> price { get; set; }

        public virtual author author { get; set; }
        public virtual book book { get; set; }
    }

}
