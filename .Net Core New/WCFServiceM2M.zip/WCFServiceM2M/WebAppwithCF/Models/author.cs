﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppwithCF.Models
{
    public class author
    {
        public author()
        {
            this.authorbooks = new HashSet<authorbook>();
        }
        [Key]
        public int aid { get; set; }
        public string aname { get; set; }
        public virtual ICollection<authorbook> authorbooks { get; set; }
    }
}
