﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppwithCF.Models
{
    public class MarutiDataContext : DbContext
    {
        public MarutiDataContext(DbContextOptions<MarutiDataContext> options)
            : base(options)
        {

        }

        public  DbSet<author> authors { get; set; }
        public  DbSet<book> books { get; set; }
        public  DbSet<authorbook> authorbooks { get; set; }
    }
}
