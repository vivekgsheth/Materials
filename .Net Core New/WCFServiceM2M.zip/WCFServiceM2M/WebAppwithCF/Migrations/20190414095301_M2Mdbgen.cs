﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebAppwithCF.Migrations
{
    public partial class M2Mdbgen : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "authors",
                columns: table => new
                {
                    aid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    aname = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_authors", x => x.aid);
                });

            migrationBuilder.CreateTable(
                name: "books",
                columns: table => new
                {
                    bid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    btitle = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_books", x => x.bid);
                });

            migrationBuilder.CreateTable(
                name: "authorbooks",
                columns: table => new
                {
                    mixedId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    aid = table.Column<int>(nullable: false),
                    bid = table.Column<int>(nullable: false),
                    price = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_authorbooks", x => x.mixedId);
                    table.ForeignKey(
                        name: "FK_authorbooks_authors_aid",
                        column: x => x.aid,
                        principalTable: "authors",
                        principalColumn: "aid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_authorbooks_books_bid",
                        column: x => x.bid,
                        principalTable: "books",
                        principalColumn: "bid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_authorbooks_aid",
                table: "authorbooks",
                column: "aid");

            migrationBuilder.CreateIndex(
                name: "IX_authorbooks_bid",
                table: "authorbooks",
                column: "bid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "authorbooks");

            migrationBuilder.DropTable(
                name: "authors");

            migrationBuilder.DropTable(
                name: "books");
        }
    }
}
