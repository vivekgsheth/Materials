﻿using Microsoft.AspNetCore.Mvc;

namespace WebApiSample.Api.Controllers
{
    #region snippet_ControllerSignature
    [ApiController]
    public class MyBaseController
    {
    }
    #endregion
}
