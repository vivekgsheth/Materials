﻿// This class is used to create the logger type in Startup.
namespace PageFilter.Filters
{
    public class GlobalFiltersLogger
    {
    }
}
