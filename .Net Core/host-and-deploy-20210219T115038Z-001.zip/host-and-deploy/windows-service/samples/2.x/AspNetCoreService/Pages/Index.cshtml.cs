﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspNetCoreService.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
