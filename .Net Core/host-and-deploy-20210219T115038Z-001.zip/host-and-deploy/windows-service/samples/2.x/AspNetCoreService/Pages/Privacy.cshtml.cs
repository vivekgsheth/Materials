﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AspNetCoreService.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
