﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HttpClientFactorySample.Pages
{
    public class UnreliableEndpointConsumerModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}