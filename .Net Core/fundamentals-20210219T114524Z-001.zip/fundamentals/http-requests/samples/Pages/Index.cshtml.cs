﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HttpClientFactorySample.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
