# ASP.NET Using Options Sample

This sample illustrates the use of the Options pattern in an ASP.NET Core Razor Pages app. This sample demonstrates the features described in the [Options pattern](https://docs.microsoft.com/aspnet/core/fundamentals/configuration/options) topic.
