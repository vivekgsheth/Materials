# ASP.NET Hosting Startup Sample

This sample illustrates the use of [IHostingStartup](https://docs.microsoft.com/dotnet/api/microsoft.aspnetcore.hosting.ihostingstartup). This sample demonstrates the scenarios described in [Enhance an app from an external assembly](https://docs.microsoft.com/aspnet/core/fundamentals/configuration/platform-specific-configuration).
