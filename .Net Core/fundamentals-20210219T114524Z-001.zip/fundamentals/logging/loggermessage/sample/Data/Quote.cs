namespace LoggerMessageSample.Data
{
    public class Quote
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}
