# ASP.NET Core LoggerMessage Sample

This sample illustrates the use of [LoggerMessage](https://docs.microsoft.com/dotnet/api/microsoft.extensions.logging.loggermessage). This sample demonstrates the features described in the [High-performance logging with LoggerMessage](https://docs.microsoft.com/aspnet/core/fundamentals/logging/loggermessage) topic.
