namespace GenericHostSample
{
    internal class ServiceContainer
    {
    }
}
