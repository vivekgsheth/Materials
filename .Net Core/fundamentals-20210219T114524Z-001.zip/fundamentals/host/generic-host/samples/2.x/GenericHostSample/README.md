# ASP.NET Generic Host Sample

This sample illustrates the ASP.NET Core Generic Host [HostBuilder](https://docs.microsoft.com/dotnet/api/microsoft.extensions.hosting.ihostedservice). This sample demonstrates the features described in the [.NET Generic Host](https://docs.microsoft.com/aspnet/core/fundamentals/host/generic-host) topic.
