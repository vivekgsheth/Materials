# ASP.NET Core HTTP.sys Sample

This sample illustrates the use of HTTP.sys. This sample demonstrates the features described in the [HTTP.sys web server implementation](https://docs.microsoft.com/aspnet/core/fundamentals/servers/httpsys) topic.
