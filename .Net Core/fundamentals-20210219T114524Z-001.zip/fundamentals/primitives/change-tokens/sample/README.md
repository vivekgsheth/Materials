# ASP.NET Core Change Token Sample

This sample illustrates the use of [ChangeToken](https://docs.microsoft.com/dotnet/api/microsoft.extensions.primitives.changetoken). This sample demonstrates the features described in the [Detect changes with Change Tokens](https://docs.microsoft.com/aspnet/core/fundamentals/primitives/change-tokens) topic.

Run the sample and follow the instructions on the Index page.
