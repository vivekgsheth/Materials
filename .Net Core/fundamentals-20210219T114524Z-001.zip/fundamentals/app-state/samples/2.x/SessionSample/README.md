# ASP.NET Session Sample

This sample illustrates the use of session state. This sample demonstrates the scenarios described in the [Session and app state in ASP.NET Core](https://docs.microsoft.com/aspnet/core/fundamentals/app-state) topic.
