# ASP.NET Core Startup filter sample

This sample illustrates the use of [IStartupFilter](https://docs.microsoft.com/dotnet/api/microsoft.aspnetcore.hosting.istartupfilter). This sample demonstrates the features described in [Application Startup: Startup filters](https://docs.microsoft.com/aspnet/core/fundamentals/startup#startup-filters).
