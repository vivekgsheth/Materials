  > [!NOTE]
  > To use ASP.NET Core with .NET Framework, you must first select **.NET Framework** from the leftmost drop-down in the dialog, then you can select the desired ASP.NET Core version.

  ![Web Application (Razor Pages)](../tutorials/razor-pages/razor-pages-start/_static/np2.png)
