::: moniker range="= aspnetcore-2.0"
The ASP.NET Core 2.0 version of this tutorial can be found in [this PDF file](https://github.com/aspnet/Docs/tree/master/aspnetcore/data/ef-rp/intro/PDF-6-18-18.pdf).

The ASP.NET Core 2.1 version of this tutorial has many improvements over the 2.0 version.
::: moniker-end
