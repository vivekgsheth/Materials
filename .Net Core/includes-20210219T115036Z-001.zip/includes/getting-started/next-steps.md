### Next steps

* An ASP.NET Core app can use the .NET Core or .NET Framework Base Class Library and runtime. For more information, see [Choosing between .NET Core and .NET Framework](/dotnet/articles/standard/choosing-core-framework-server).
* [Getting started tutorials](xref:tutorials/index)
* [Introduction to ASP.NET Core](xref:index) 
* [ASP.NET Core architecture and fundamentals](xref:fundamentals/index).
