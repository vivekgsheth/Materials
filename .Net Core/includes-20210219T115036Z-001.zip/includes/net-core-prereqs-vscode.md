Install the following:

::: moniker range="<= aspnetcore-2.0"
* [!INCLUDE [](~/includes/net-core-sdk-download-link.md)]
* [Visual Studio Code](https://code.visualstudio.com/download)
* [C# for Visual Studio Code](https://marketplace.visualstudio.com/items?itemName=ms-vscode.csharp)
::: moniker-end
::: moniker range=">= aspnetcore-2.1"
* [!INCLUDE [](~/includes/2.1-SDK.md)]
* [Visual Studio Code](https://code.visualstudio.com/download)
* [C# for Visual Studio Code](https://marketplace.visualstudio.com/items?itemName=ms-vscode.csharp)
::: moniker-end
