::: moniker range="= aspnetcore-2.0"

We recommend you follow the [ASP.NET Core 2.1 version](xref:razor-pages-start?view=aspnetcore-2.1) of this tutorial. It's easier to follow and covers more features.

 [view link](?view=aspnetcore-2.1)

::: moniker-end
