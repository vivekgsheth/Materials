Assume the app's *secrets.json* file contains the following two secrets:

[!INCLUDE[secrets.json file](secrets-json-file.md)]
