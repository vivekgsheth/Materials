> [!NOTE]
> In ASP.NET Core 2.1 or later, `webapp` is an alias of the `razor` argument. If the `dotnet new webapp <OPTIONS>` command loads the [dotnet new](/dotnet/core/tools/dotnet-new) command help instead of creating a new Razor Pages app, install the [.NET Core 2.1 SDK](https://www.microsoft.com/net/download/dotnet-core/sdk-2.1.300).
