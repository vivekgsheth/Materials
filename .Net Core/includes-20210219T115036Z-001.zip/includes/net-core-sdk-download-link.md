[.NET Core SDK 2.0 or later](https://www.microsoft.com/net/download)
