> [!NOTE]
> This document details the latest version of ASP.NET Core SignalR. See the [SignalR 1.x documentation](/aspnet/signalr/) for the ASP.NET Framework version.
