[Visual Studio 2017 version 15.7.3 or later](https://www.microsoft.com/net/download/windows) with the following workloads:

* **ASP.NET and web development**
* **.NET Core cross-platform development**

::: moniker range=">= aspnetcore-2.1"
[.NET Core 2.1 SDK or later](https://www.microsoft.com/net/download/windows)
::: moniker-end
