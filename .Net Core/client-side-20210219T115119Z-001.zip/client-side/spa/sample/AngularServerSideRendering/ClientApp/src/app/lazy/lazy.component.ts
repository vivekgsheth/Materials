import { Component } from '@angular/core';

@Component({
  selector: 'lazy-component',
  templateUrl: './lazy.component.html'
})
export class LazyComponent {
}
