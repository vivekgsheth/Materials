namespace RazorPagesProject
{
    public class GithubUser
  {
      public string Login { get; set; }
      public string Name { get; set; }
      public string Company { get; set; }
  }
}
