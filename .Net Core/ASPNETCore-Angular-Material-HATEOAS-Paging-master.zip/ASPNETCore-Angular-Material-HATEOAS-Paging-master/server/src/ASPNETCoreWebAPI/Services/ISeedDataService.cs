﻿using System.Threading.Tasks;

namespace ASPNETCoreWebAPI.Services
{
    public interface ISeedDataService
    {
        void EnsureSeedData();
    }
}
