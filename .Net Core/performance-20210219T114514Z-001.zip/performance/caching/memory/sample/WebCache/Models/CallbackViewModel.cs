﻿using System;

namespace WebCacheSample.Models
{
    public class CallbackViewModel
    {
        public DateTime? CachedTime { get; set; }
        public string Message { get; set; }
    }
}
