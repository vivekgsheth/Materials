﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ResponseCachingMiddleware.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
