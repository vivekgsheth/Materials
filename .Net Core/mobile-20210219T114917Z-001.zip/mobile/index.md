---
title: Mobile development with ASP.NET Core
author: rick-anderson
description: Find out about topics that pertain to mobile development with ASP.NET Core.
ms.author: riande
ms.date: 10/14/2016
uid: mobile/index
---
# Mobile development with ASP.NET Core

*   [Create backend services for native mobile apps](native-mobile-backend.md)
