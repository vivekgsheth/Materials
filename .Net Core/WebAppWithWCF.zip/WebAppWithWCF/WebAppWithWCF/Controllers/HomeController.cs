﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAppWithWCF.Models;

namespace WebAppWithWCF.Controllers
{
    public class HomeController : Controller
    {
        ServiceReference1.ServiceClient obj;
        public IActionResult Index()
        {
            obj = new ServiceReference1.ServiceClient();
            var allemp = obj.GetAllEmpAsync().Result;
            return View(allemp);
        }
        public IActionResult Create()
        {           
            return View();
        }
        [HttpPost]
        public IActionResult Create(ServiceReference1.Emp em)
        {
            if (ModelState.IsValid)
            {
                obj = new ServiceReference1.ServiceClient();
                obj.AddEmpAsync(em);
                return RedirectToAction("Index");
            }
            return View();
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            obj = new ServiceReference1.ServiceClient();
            var allemp = obj.GetAllEmpAsync().Result;
            var oneemp = allemp.Single(x => x.Id == id);            
            return View(oneemp);
        }
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            obj = new ServiceReference1.ServiceClient();
            await  obj.DeleteEmpAsync(id);
            return RedirectToAction("Index");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
