﻿using Microsoft.AspNetCore.SignalR;

namespace SignalRNotify
{
    public class NotificationHub : Hub
    {
    }
}
