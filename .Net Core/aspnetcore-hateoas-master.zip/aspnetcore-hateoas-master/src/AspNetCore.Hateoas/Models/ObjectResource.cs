﻿namespace AspNetCore.Hateoas.Models
{
    public class ObjectResource : Resource
    {
        public ObjectResource(object data) : base(data)
        {
        }
    }
}
