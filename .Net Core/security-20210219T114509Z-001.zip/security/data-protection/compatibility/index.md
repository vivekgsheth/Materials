---
title: Compatibility in ASP.NET Core
author: rick-anderson
description: This document serves as a table of contents for various ASP.NET Core data protection compatibility topics.
ms.author: riande
ms.date: 10/14/2016
uid: security/data-protection/compatibility/index
---
# Compatibility in ASP.NET Core

* [Replacing ASP.NET \<machineKey> in ASP.NET Core](xref:security/data-protection/compatibility/replacing-machinekey)
