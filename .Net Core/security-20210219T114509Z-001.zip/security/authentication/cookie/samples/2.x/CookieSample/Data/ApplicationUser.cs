namespace CookieSample.Data
{
    public class ApplicationUser
    {
        public string Email { get; set; }
        public string FullName { get; set; }
    }
}
