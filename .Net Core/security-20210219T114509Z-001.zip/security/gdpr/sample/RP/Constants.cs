﻿namespace RPCC
{
    internal static class Constants
    {
        public const string EssentialSec = "EssentialSec";
        public const string NonEssentialMS = "NonEssentialMS";
    }
}