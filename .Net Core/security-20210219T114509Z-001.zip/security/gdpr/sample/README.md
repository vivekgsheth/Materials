# GDPR Sample

* In *appsettings.json*, set `CheckNotConsentNeeded` to `false` to require consent; otherwise set to true or omit. Test the app with `CheckNotConsentNeeded` set to `false` and set to `true`.
* Create essential and non-essential cookies with each variation of `CheckConsentNeeded` and consent granted.
* Register a user.
* Delete cookies.
