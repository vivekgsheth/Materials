﻿using Microsoft.AspNetCore.Authorization;

namespace PoliciesAuthApp1.Services.Requirements
{
    public class EditPermission : IAuthorizationRequirement
    {
        // Code omitted for brevity
    }
}