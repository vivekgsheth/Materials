﻿namespace PoliciesAuthApp1.Services.Requirements
{
    #region snippet_BuildingEntryRequirementClass
    using Microsoft.AspNetCore.Authorization;

    public class BuildingEntryRequirement : IAuthorizationRequirement
    {
    }
    #endregion
}
