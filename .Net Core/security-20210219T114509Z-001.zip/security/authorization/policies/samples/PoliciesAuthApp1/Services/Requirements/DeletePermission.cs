﻿using Microsoft.AspNetCore.Authorization;

namespace PoliciesAuthApp1.Services.Requirements
{
    public class DeletePermission : IAuthorizationRequirement
    {
        // Code omitted for brevity
    }
}