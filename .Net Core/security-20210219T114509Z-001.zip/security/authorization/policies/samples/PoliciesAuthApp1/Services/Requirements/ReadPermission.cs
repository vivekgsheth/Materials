﻿using Microsoft.AspNetCore.Authorization;

namespace PoliciesAuthApp1.Services.Requirements
{
    public class ReadPermission : IAuthorizationRequirement
    {
        // Code omitted for brevity
    }
}