using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CookieAuthCore.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
