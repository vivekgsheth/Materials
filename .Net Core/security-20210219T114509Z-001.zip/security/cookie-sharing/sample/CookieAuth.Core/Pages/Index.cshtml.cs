﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CookieAuthCore.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
