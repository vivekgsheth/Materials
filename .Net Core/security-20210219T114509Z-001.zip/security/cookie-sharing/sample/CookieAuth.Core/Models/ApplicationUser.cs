namespace CookieAuthCore.Models
{
    public class ApplicationUser
    {
        public int Id { get; set; }
        public string Email { get; set; }
    }
}
