﻿using System.Web.Mvc;

namespace Asp.Net4.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
