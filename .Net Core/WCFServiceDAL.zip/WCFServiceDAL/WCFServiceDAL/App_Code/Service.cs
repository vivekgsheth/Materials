﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    DatabaseEntities _db = new DatabaseEntities();
    public List<Emp> GetAllEmp()
    {
        return _db.Emps.ToList();
    }
    public void AddEmp(Emp em)
    {
        _db.Emps.Add(em);
        _db.SaveChanges();
    }

    public void DeleteEmp(int id)
    {
        var etd = _db.Emps.Single(x => x.Id == id);
        _db.Emps.Remove(etd);
        _db.SaveChanges();
    } 

    public void UpdateEmp(int id, Emp em)
    {
        var etu = _db.Emps.Single(x => x.Id == id);
        etu.Name = em.Name;
        etu.Age = em.Age;
        etu.Email = em.Email;
        _db.SaveChanges();
    }
}
