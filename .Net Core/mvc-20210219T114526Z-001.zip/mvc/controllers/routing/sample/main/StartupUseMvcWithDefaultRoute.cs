﻿/*
#region snippet
// In Startup class
public void Configure(IApplicationBuilder app)
{
    app.UseMvcWithDefaultRoute();
}
#endregion
*/