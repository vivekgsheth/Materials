﻿/*
#region snippet_1
// In Startup class
public void Configure(IApplicationBuilder app)
{
    app.UseMvc();
}
#endregion
*/