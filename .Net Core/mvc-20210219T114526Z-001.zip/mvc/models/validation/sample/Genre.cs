﻿namespace MVCMovie.Models
{
    public enum Genre
    {
        Classic,
        PostClassic,
        Modern,
        PostModern,
        Contemporary,
    }
}