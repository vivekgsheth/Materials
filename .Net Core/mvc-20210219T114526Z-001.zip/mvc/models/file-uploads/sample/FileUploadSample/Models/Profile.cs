﻿namespace FileUploadSample.Models
{
    public class Profile
    {
        public string Name { get; set; }
        public string AvatarPath { get; set; }
    }
}