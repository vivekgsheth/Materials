namespace PartialViewsSample.ViewModels
{
    public class ArticleSection
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}