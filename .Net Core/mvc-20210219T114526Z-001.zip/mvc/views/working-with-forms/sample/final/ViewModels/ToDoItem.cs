﻿namespace FormsTagHelper.ViewModels
{
    public class ToDoItem
    {
        public string Name { get; set; }

        public bool IsDone { get; set; }
    }
}
