﻿using System.ComponentModel.DataAnnotations;

namespace FormsTagHelper.ViewModels
{
    public class AddressViewModel
    {
        public string AddressLine1 { get; set; }
    }
}

