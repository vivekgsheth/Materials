﻿namespace FormsTagHelper.ViewModels
{
    public class CountryEnumViewModel
    {
        public CountryEnum EnumCountry { get; set; }
    }
}
