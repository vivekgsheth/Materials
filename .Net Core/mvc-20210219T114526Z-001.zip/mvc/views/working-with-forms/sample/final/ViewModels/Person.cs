﻿using System.Collections.Generic;

namespace FormsTagHelper.ViewModels
{
    public class Person
    {
        public List<string> Colors { get; set; }

        public int Age { get; set; }
    }
}
