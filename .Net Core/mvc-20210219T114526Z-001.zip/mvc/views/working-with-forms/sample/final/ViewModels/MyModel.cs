﻿namespace FormsTagHelper.ViewModels
{
    public class MyModel
    {
        public string Name { get; set; }
    }
}
