﻿namespace RazorSample.Models
{
    public class LoginViewModel
    {
        public string Email { get; set; }
    }
}
