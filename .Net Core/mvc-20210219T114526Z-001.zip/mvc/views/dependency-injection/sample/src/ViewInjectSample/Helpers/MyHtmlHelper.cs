﻿namespace ViewInjectSample.Helpers
{
    public class MyHtmlHelper
    {
        public MyHtmlHelper()
        {
            Value = "Hello from MyHtmlHelper";
        }
        public string Value { get; set; }
    }
}
