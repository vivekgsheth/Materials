﻿namespace ViewInjectSample.Model
{
    public class ToDoItem
    {
        public string Name { get; set; }
        public int Priority { get; set; }
        public bool IsDone { get; set; }
    }
}
