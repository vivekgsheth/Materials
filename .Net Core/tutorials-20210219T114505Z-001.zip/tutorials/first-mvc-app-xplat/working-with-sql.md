---
title: Work with SQLite in an ASP.NET Core MVC app
author: rick-anderson
description: Using SQLite with a simple MVC app
ms.author: riande
ms.date: 04/07/2017
uid: tutorials/first-mvc-app-xplat/working-with-sql
---

[!INCLUDE [adding-model](../../includes/mvc-intro/sql.md)]

> [!div class="step-by-step"]
> [Previous - Add a model](adding-model.md)
> [Next - Controller methods and views](controller-methods-views.md)
