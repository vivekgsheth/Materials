---
title: Add a new field to an ASP.NET Core app
author: rick-anderson
description: Shows you how to add an new field to an exiting ASP.NET Core EF/MVC app.
ms.author: riande
ms.date: 04/14/2017
uid: tutorials/first-mvc-app-mac/new-field
---

[!INCLUDE [adding-field](../../includes/mvc-intro/new-field.md)]

> [!div class="step-by-step"]
> [Previous - Add search](search.md)
> [Next - Add validation](validation.md)
