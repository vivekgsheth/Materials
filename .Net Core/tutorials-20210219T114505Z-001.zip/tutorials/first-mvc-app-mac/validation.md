---
title: Add validation to an ASP.NET Core app
author: rick-anderson
description: How to add validation to a simple ASP.NET Core app.
ms.author: riande
ms.date: 06/13/2017
uid: tutorials/first-mvc-app-mac/validation
---

[!INCLUDE [validation](../../includes/mvc-intro/validation.md)]

> [!div class="step-by-step"]
> [Previous - Add a field](new-field.md)
> [Next - Examine the Details and Delete methods](xref:tutorials/first-mvc-app/details)


