---
title: Add search to an ASP.NET Core Razor Pages app
author: rick-anderson
description: Shows how to add search to ASP.NET Core Razor Pages
monikerRange: '>= aspnetcore-2.0'
ms.author: riande
ms.date: 08/07/2017
uid: tutorials/razor-pages-vsc/search
---

[!INCLUDE [Search](../../includes/RP/search.md)]

> [!div class="step-by-step"]
> [Previous: Updating the pages](xref:tutorials/razor-pages-vsc/da1)
> [Next: Adding a new field](xref:tutorials/razor-pages/new-field)
