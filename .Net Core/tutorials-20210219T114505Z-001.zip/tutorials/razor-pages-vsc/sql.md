---
title: Work with SQLite in an ASP.NET Core Razor Pages app
author: rick-anderson
description: Using SQLite with Razor Pages
monikerRange: '>= aspnetcore-2.0'
ms.author: riande
ms.date: 1/27/2018
uid: tutorials/razor-pages-vsc/sql
---

[!INCLUDE [SQLlite](../../includes/RP/sql.md)]

> [!div class="step-by-step"]
> [Previous: Adding a model](xref:tutorials/razor-pages-vsc/model)
> [Next: Update the pages](xref:tutorials/razor-pages-vsc/da1)
