---
title: Add validation to an ASP.NET Core MVC app
author: rick-anderson
description: How to add validation to an ASP.NET Core app.
ms.author: riande
ms.date: 04/13/2017
uid: tutorials/first-mvc-app/validation
---

[!INCLUDE [validation](~/includes/mvc-intro/validation.md)]

> [!div class="step-by-step"]
> [Previous](new-field.md)
> [Next](details.md)  
