﻿// This code exists only for inclusion in the associated doc.
#define NEVER

#if ALWAYS
#region snippet_ChatHubStubClass
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SignalRWebPack.Hubs
{
    public class ChatHub : Hub
    {
    }
}
#endregion
#endif