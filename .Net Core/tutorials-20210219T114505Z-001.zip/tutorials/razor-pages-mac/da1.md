---
title: Update the generated pages
author: rick-anderson
description: Update the generated pages with better display.
monikerRange: '>= aspnetcore-2.0'
ms.author: riande
ms.date: 08/07/2017
uid: tutorials/razor-pages-mac/da1
---
[!INCLUDE [model1](../../includes/RP/da1.md)]

[!INCLUDE [model1](../../includes/RP/da2.md)]

> [!div class="step-by-step"]
> [Previous: Work with SQLlite](xref:tutorials/razor-pages-mac/sql)
> [Add search](xref:tutorials/razor-pages-mac/search)
