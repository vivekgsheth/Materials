The code in this folder is snapshots in time from the Razor Pages series.
